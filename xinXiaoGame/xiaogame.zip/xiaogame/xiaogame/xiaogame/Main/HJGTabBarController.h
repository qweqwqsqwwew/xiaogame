//
//  HJGTabBarController.h
//  Lottery
//
//  Created by DH on 2017/7/26.
//  Copyright © 2017年 DH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HJGTabBarController : UITabBarController

@end
