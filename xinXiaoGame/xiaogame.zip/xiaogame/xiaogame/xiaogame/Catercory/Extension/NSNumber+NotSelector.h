//
//  NSNumber+NotSelector.h
//  games
//
//  Created by DavidYang on 15/6/19.
//
//

#import <Foundation/Foundation.h>

@interface NSNumber(NotSelector)

@end
