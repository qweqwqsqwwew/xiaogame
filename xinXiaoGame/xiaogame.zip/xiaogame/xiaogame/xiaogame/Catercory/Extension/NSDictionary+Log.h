//
//  NSDictionary+Log.h
//  QT
//
//  Created by Heisenbean on 16/8/3.
//  Copyright © 2016年 DavidYang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (Log)

@end
