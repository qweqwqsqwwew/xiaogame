//
//  NSMutableSet+Addition.h
//  Alien
//
//  Created by DavidYang on 15/5/22.
//  Copyright (c) 2015年 hupu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSMutableSet(Addition)

- (void)addSafeObject:(id)object;

@end
