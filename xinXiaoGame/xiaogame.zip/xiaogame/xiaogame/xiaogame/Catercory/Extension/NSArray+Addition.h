//
//  NSArray+Addition.h
//  games
//
//  Created by DavidYang on 15/7/8.
//
//

#import <Foundation/Foundation.h>

@interface NSArray (Addition)

- (id)safeObjectAtIndex:(NSUInteger)index;

@end
