//
//  UIlabelExtension.h
//  CJ
//
//  Created by weflytotti on 14/11/16.
//  Copyright (c) 2014年 weflytotti. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel(Extension)

-(CGSize)lblContentSize:(CGSize)size;

@end
