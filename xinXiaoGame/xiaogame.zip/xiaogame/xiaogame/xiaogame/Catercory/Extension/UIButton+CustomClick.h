//
//  UIButton+CustomClick.h
//  Lottery
//
//  Created by Developer on 2018/4/14.
//  Copyright © 2018年 DH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (CustomClick)

@property (nonatomic, assign) NSTimeInterval custom_acceptEventInterval;

@end
