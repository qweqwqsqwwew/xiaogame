//
//  HJGGoogleA.h
//  Lottery
//
//  Created by Developer on 2017/12/19.
//  Copyright © 2017年 DH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HJGGoogleA : NSObject

- (void)current_iso:(NSString *)iso ActionTip:(NSString *)actionTip;

+(instancetype)shareGoogleA;

@end
