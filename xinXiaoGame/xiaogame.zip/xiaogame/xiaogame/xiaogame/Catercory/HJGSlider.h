//
//  HJGSlider.h
//  Lottery
//
//  Created by Developer on 2017/11/30.
//  Copyright © 2017年 DH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HJGSlider : UISlider

@end
