//
//  NSDate+SwitchForm.h
//  NestHouse
//
//  Created by shansander on 2017/7/12.
//  Copyright © 2017年 DH. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (SwitchForm)

+ (NSDate *)getDateFromString:(NSString *)date_string;

@end
