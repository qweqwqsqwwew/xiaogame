//
//  UILabel+adjustsFontSizeToFitWidth.h
//  NestHouse
//
//  Created by shansander on 2017/5/24.
//  Copyright © 2017年 DH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (adjustsFontSizeToFitWidth)

- (NSInteger)getFontSize;

@end
