//
//  UIColor+AppTheme.m
//  NestHouse
//
//  Created by shansander on 2017/6/9.
//  Copyright © 2017年 DH. All rights reserved.
//

#import "UIColor+AppTheme.h"

@implementation  UIColor (AppTheme)

+ (UIColor *)appThemeMainBackGroupColor
{
    return [UIColor colorWithHexRGB:0xf6f6fa];
}

@end
