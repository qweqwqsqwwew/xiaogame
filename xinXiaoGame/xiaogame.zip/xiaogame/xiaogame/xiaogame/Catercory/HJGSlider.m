//
//  HJGSlider.m
//  Lottery
//
//  Created by Developer on 2017/11/30.
//  Copyright © 2017年 DH. All rights reserved.
//

#import "HJGSlider.h"

@implementation HJGSlider


- (CGRect)trackRectForBounds:(CGRect)bounds {
    return CGRectMake(0, 0, WIDTH - W(114), H(5));
}


@end
