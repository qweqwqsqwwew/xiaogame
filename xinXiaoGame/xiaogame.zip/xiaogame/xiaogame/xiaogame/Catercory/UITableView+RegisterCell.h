//
//  UITableView+RegisterCell.h
//  NestHouse
//
//  Created by shansander on 2017/3/29.
//  Copyright © 2017年 DH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface UITableView (RegisterCell)

- (void)registerClass:(Class)aclass;

@end
