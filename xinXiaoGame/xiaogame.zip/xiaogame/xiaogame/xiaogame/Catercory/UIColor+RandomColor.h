//
//  UIColor+RandomColor.h
//  NestHouse
//
//  Created by shansander on 2017/7/20.
//  Copyright © 2017年 DH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (RandomColor)

+ (UIColor *)randomColor;

@end
