//
//  HJGSettingController.h
//  xiaogame
//
//  Created by Developer on 2018/8/4.
//  Copyright © 2018年 Developer. All rights reserved.
//

#import "HJGBaseController.h"

@interface HJGSettingController : HJGBaseController

@end
